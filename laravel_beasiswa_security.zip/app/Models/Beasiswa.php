<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Beasiswa extends Model
{
    use HasFactory;

    protected $fillable = ['nama_beasiswa', 'deskripsi'];

    public function penerimas()
    {
        return $this->hasMany(PenerimaBeasiswa::class);
    }
}
