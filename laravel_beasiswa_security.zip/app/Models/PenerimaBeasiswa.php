<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Spatie\Activitylog\Traits\LogsActivity;

class PenerimaBeasiswa extends Model
{
    use HasFactory, LogsActivity;

    protected $fillable = ['beasiswa_id', 'nama_lengkap', 'nim', 'email', 'nominal'];

    protected $casts = [
        'email' => 'encrypted',
        'nim' => 'encrypted',
    ];

    protected static $logAttributes = ['nama_lengkap', 'nim', 'email', 'nominal'];
    protected static $logName = 'penerima_beasiswa';

    public function beasiswa()
    {
        return $this->belongsTo(Beasiswa::class);
    }
}
